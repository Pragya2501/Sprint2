import React from "react";
import './App.css';
import { BrowserRouter as Router,Switch, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import AboutUs from "./components/AboutUs";
import User from "./components/User";
import Admin from "./components/Admin";
import Patient from "./components/Patient";
import DiagnosticCenter from "./components/DiagnosticCenter";
import Appointment from "./components/Appointment";
import PersonDiagnostic from "./components/PatientDiagnostic";
import UpdateDiagnostic from "./components/UpdateDiagnostic";
import DiagnosticTest from "./components/DiagnosticTest";
import TestResult from "./components/TestResult";
import ViewAppointmentAdmin from "./components/ViewAppointmentAdmin";

function App() {
  return (
    <div className="App">
      <Router>
      <nav className="navbar navbar-expand-lg navbar-dark nav-bk1">
  <div className="container-fluid">
  
   
    <a className="navbar-brand" href="#">Health Care System</a>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse navalign">
      <ul className="navbar-nav ">
      <li className="nav-item outline">
          <Link className="nav-link active"  to={"/aboutus"}>Home</Link>
        </li>
        <li className="nav-item outline">
          <Link className="nav-link active"  to={"/user"}>User</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link active" to={"/admin"}>Admin</Link>
        </li>
        <li className="nav-item">
          <a className="nav-link active" href="" >AboutUs</a>
        </li>
      </ul>
      <form className="d-flex">
        <input className="form-control me-2" type="search" placeholder="How May I Help You?" aria-label="Search"/>
        <button className="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
      <div className="container mt-3">
        
        <Switch>
          <Route exact path={["/", "/aboutus"]} component={AboutUs} />
          <Route exact path="/user" component={User} />
          <Route path="/admin" component={Admin} />
          <Route path="/patient" component={Patient}/>
          <Route exact path="/diagcen" component={DiagnosticCenter}/>
          <Route path="/appointment" component ={Appointment}/>
          <Route path="/patientdiag" component={PersonDiagnostic}/>
          <Route path="/diagcen/upd" component ={UpdateDiagnostic}/>
          <Route path="/diagcentest" component={DiagnosticTest}/>
          <Route path="/testresult" component ={TestResult}/>
          <Route path="/viewapt" component={ViewAppointmentAdmin}/>
        </Switch>
        
      </div>
      </Router>
    </div>
  );
}

export default App;
