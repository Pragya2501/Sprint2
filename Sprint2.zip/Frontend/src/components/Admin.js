import axios from "axios";
import React, { useState, useEffect } from "react";
import adminimg from "./images/admin.jpg";
import { Link } from "react-router-dom";
const Admin=()=>{
    const[patient,setPatient]=useState([]);
    //const[diagnostic,setDiagnostic]=useState([]);
    const[inputPatient,setInput]=useState("");

    const clickHandler=()=>{
        axios
        .get(`http://localhost:8080/api/patients/view/${inputPatient}`)
        .then((response)=>{
            setPatient(response.data);
            console.log(response);
        })
        .catch((error)=>{
            console.log(error)
        });
    };
    
    //   useEffect(()=>{
        

    //     axios
    //     .get(`http://localhost:8080/api/diagnosticCenter/list`)
    //     .then((response)=>{
    //         setDiagnostic(response.data);
    //         console.log(response.data);
    //     })
    //     .catch((error)=>{
    //         console.log(error)
    //     });
        
    //   });

      const inputHandler=(e)=>{
        setInput(e.target.value);
        console.log(e.target.value);
      };

    return(
        <div style={{
            background: `url(${adminimg})`,
            height: '100vh',
            backgroundSize: 'cover'
          }} >
        
      {/*******************Form code**************/}
      <div className="container">
  <div className="row">
      <div className="col-md-4">
      </div>
      <div className="col-md-4">
          
<h2 className="heading1">Admin</h2>
<div className="form">
  <form>
      <div className="card">
          <div className="card-body">
              <div className="d-flex justify-content-center">
              </div>
         <div className="input-group">
              <input type="text"
                  className="form-control"
                  onChange={inputHandler}
                  placeholder="Search By Patient Name"/>
          </div>
      <br/>
          
          <div className="col-2 mt-2 ">
              <button  id="submit" className="btn btn-primary
                  btn-block" onClick={clickHandler}>Search Patient</button>
          </div>
          </div>
          <div className="viewpatient">
          {patient && (
           <div >
        <p>{patient.name}</p>
        <p>{patient.phoneNo}</p>
        <p>{patient.age}</p>
        <p>{patient.gender}</p>
       
        </div>
        )}
          </div>
      </div>
  </form>
</div>
</div>
</div>
</div>

<br/>
<div className="container">
  <div className="row">
    <div className="col">
    <Link to={"/viewapt"} id="testresbtn"className="btn btn-info" role="button">View Appointment</Link></div>
    <div className="col">
    <Link to={"/diagcen"} id="dcbtn" className="btn btn-info" role="button">Create DiagnosticCenters</Link>
    </div>
  
</div>
     </div>
     </div>
    )
}

export default Admin;