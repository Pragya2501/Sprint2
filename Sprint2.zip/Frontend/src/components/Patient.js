import { useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import backgroundimg from "./images/Patient.jpg";

const Patient=()=>{
    const initialPatient={
        Id:null,
        name:"",
        phoneNo:"",
        age:null,
        gender:"",
    };
    const [patient,setPatient]=useState(initialPatient);

    const handleInputChange=event=>{
        const {name,value}=event.target;
        setPatient({...patient,[name]:value});
    };
    const savePatient=()=>{
        var data={
            name:patient.name,
        phoneNo:patient.phoneNo,
        age:patient.age,
        gender:patient.gender,
        };

        axios
        .post(`http://localhost:8080/api/patients/add`,data)
        .then(response=>{
            setPatient({
                Id:response.data.Id,
                name:response.data.name,
                phoneNo:response.data.phoneNo,
                age:response.data.age,
                gender:response.data.gender
            });
        })
        .catch(e=>{
            console.log(e);
        });
    }

    return(
      <div style={{
        background: `url(${backgroundimg})`,
        height: '120vh',
        backgroundSize: 'cover'
      }} >


<div className="container">
<div className="row">
  <div className="col-md-4">
  </div>
  <div className="col-md-4">
      
<h2 className="heading">Patient Login</h2>
<div className="form">
<form>
  <div className="card1">
      <div className="card-body">
          <div className="d-flex justify-content-center">
          </div>
     <div className="input-group">
          <input type="text"
              className="form-control1"
              id="name"
              required
            value={patient.name}
              onChange={handleInputChange}
              name="name"
              placeholder="Patient Name"/>
      </div>
    <br/>
      <div className="input-group">
          <input type="text"
              className="form-control1"
              id="phoneNo"
              required
            value={patient.phoneNo}
               onChange={handleInputChange}
              name="phoneNo"
              placeholder="Phone Number"/>
      </div>
  <br/>
      <div className="input-group">
          <input type="text"
              className="form-control1"
              id="age"
              required
            value={patient.age}
                onChange={handleInputChange}
              name="age"
              placeholder="Age"/>
      </div>
      <br/>
      <div className="input-group">
          <input type="text"
              className="form-control1"
              id="gender"
              required
            value={patient.gender}
                onChange={handleInputChange}
              name="gender"
              placeholder="gender"/>
      </div>
      <div className="col-2 mt-2 ">
          <button id="submit1" className="btn btn-primary
              btn-block" onClick={savePatient}>Submit</button>
      </div>
      </div>
  </div>
</form>
</div>
</div>
</div>
</div>
<br/>
<div className="container">
<div className="row">
{/* <div className="col">
  <button id="btnDelete" className="btn btn-danger btn-block">Delete</button></div>
<div className="col">
  <button id="btnUpdate" className="btn btn-success btn-block">Update</button></div>
</div>
<div className="col"> */}
<Link id="patientbtn" className="nav-link active"  to={"/patientdiag"} role="button">View Diagnostic Center</Link>
</div>
</div>

</div>
    )
}

export default Patient;