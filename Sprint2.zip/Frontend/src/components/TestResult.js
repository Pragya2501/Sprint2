import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import testresultbackgroundimg from "./images/testresultbackimg.jpg";

const TestResult=()=>{

    const initialTest={
        id:null,
        testReading:null,
        condition:"",
    };

    
    const [test,setTest]=useState(initialTest);
    const [appointmentId,setAppointmentId]=useState(null);
    const handleInputChange=event=>{
        const {name,value}=event.target;
        setTest({...test,[name]:value});
    };

    const handleInputChange1=e=>{
       setAppointmentId(e.target.value);
    };

    const saveTestResult=()=>{
        var data={
            testReading:test.testReading,
            condition:test.condition,
        };

        axios
        .post(`http://localhost:8080/test/${appointmentId}`,data)
        .then(response=>{
            setTest({
                id:response.data.id,
                testReading:response.data.testReading,
                condition:response.data.condition,
            });
        })
        .catch(e=>{
            console.log(e);
        });
    }




    return(
        <div style={{
            background: `url(${testresultbackgroundimg})`,
            height: '100vh',
            backgroundSize: 'cover'
          }} >


<div class="container">
  <div class="row">
      <div class="col-md-4">
      </div>
      <div class="col-md-4">
          
<h2 className="heading">Tests Results</h2>
<div class="form">
  <form>
      <div class="card">
          <div class="card-body">
              <div class="d-flex justify-content-center">
              </div>
         <div class="input-group">
              <input type="text"
                  class="form-control"
                  id="appointmentid"
              required
             //value={user.username}
               onChange={handleInputChange1}
              name="appointmentId"
                  placeholder=" Appointment Id"/>
          </div>
        <br/>
          <div class="input-group">
              <input type="text"
                  class="form-control"
                  id="testReading"
              required
             value={test.testReading}
               onChange={handleInputChange}
              name="testReading"
                  placeholder="Test Reading"/>
          </div>
      <br/>
          <div class="input-group">
              <input type="text"
                  class="form-control"
                  id="condition"
              required
            value={test.condition}
               onChange={handleInputChange}
              name="condition"
                  placeholder="Condition of Patient"/>
          </div>
          
          <div class="col-2 mt-2 ">
              <button id="submit" class="btn btn-primary
                  btn-block" onClick={saveTestResult}>Submit</button>
          </div>
          </div>
      </div>
  </form>
</div>
</div>
</div>
</div>
<br/>
<div class="container">
  <div class="row">
    <div class="col">
    <Link to={"/viewtr"} id="testresbtn"class="btn btn-info" role="button">View Test Result</Link>
    </div>
     
    <div class="col">
      <button id="btnUpdate" class="btn btn-success btn-block">Update</button></div>
  </div>
</div>
</div>
        
    )
}

export default TestResult;