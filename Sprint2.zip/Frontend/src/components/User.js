import { useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import background from "./images/User.jpg";
const User=()=>{
    const initialuser={
        id:null,
        username: "",
        password:"",
        role:"",
    };
    const [user,setUser] = useState(initialuser);

    const handleInputChange=event=>{
        
        const {name,value}= event.target;
        setUser({...user,[name]:value});
    };

    const saveUser=()=>{
      user.role="user";
        var data={
            username:user.username,
            password:user.password,
            role:user.role,
        };

        axios
        .post(`http://localhost:8080/api/users/add`,data)
        .then(response=>{
            setUser({
                id:response.data.id,
                username:response.data.username,
                password:response.data.password,
                role:response.data.role
            });
        })
        .catch(e=>{
            console.log(e);
        });

    };

    return(
      <div style={{
        backgroundImage: `url(${background})`,
        height: '100vh',
        backgroundSize:'cover'
 }}
    >
        
    <div className="container">
<div className="row">
    <div className="col-md-4">
    </div>
    <div className="col-md-4">
        
<h2 className="heading">User Login</h2>
<div className="form">
<form>
    <div className="card1">
        <div className="card-body">
            <div className="d-flex justify-content-center">
            </div>
       <div className="input-group">
            <input type="text"
                className="form-control1"
                id="username"
              required
             value={user.username}
               onChange={handleInputChange}
              name="username"
                placeholder="UserName"/>
        </div>
      <br/>
        <div className="input-group">
            <input type="password"
                className="form-control1"
                id="password"
              required
            value={user.password}
               onChange={handleInputChange}
              name="password"
                placeholder="Password"/>
        </div>
    <br/>
        <div className="col-2 mt-2 ">
          <Link to="/patient">
            <button id="submit1" className="btn btn-primary
                btn-block" onClick={saveUser}>Submit</button>
            </Link>
        </div>
        </div>
    </div>
</form>
</div>
</div>
</div>
</div>


</div>
    )
}

export default User;