import { useState,useEffect } from "react";
import { Link } from "react-router-dom";
import dchealth from "./images/dcimg.jpg";
import axios from "axios";

const DiagnosticCenter=()=>{
    const initialDiagnostic={
        id:null,
        name:"",
        contactNo:"",
        address:"",
        contactEmail:""
    };

    
    const [diagnostic,setDiagnostic]=useState(initialDiagnostic);
    const[diagnostic1,setDiagnostic1]=useState([]);
    const handleInputChange=event=>{
        const {name,value}=event.target;
        setDiagnostic({...diagnostic,[name]:value});
    };

    const saveDiag=()=>{
        var data={
            name:diagnostic.name,
        contactNo:diagnostic.contactNo,
        address:diagnostic.address,
        contactEmail:diagnostic.contactEmail,
        };

        axios
        .post(`http://localhost:8080/api/diagnosticCenter/`,data)
        .then(response=>{
            setDiagnostic({
                id:response.data.id,
                name:response.data.name,
                contactNo:response.data.contactNo,
                address:response.data.address,
                contactEmail:response.data.contactEmail
            });
        })
        .catch(e=>{
            console.log(e);
        });
    }


    useEffect(()=>{
        

      axios
      .get(`http://localhost:8080/api/diagnosticCenter/list`)
      .then((response)=>{
          setDiagnostic1(response.data);
          console.log(response.data);
      })
      .catch((error)=>{
          console.log(error)
      });
      
    });
    
    return(
      <div className="frontbackgroundimg" style={{
        backgroundImage: `url(${dchealth})`,
        height: '130vh',
        backgroundSize: 'cover'
      }} >
    

<div className="container">
<div className="row">
<div className="col-md-4">
</div>
<div className="col-md-4">
  
<h2 className="dcheading">Diagnostic Center Details</h2>

<div className="form1">
<form>
<div className="card">
  <div className="card-body">
      <div className="d-flex justify-content-center">
      </div>
  <div className="input-group">
      <input type="text"
          className="form-control"
          id="name"
              required
            value={diagnostic.name}
               onChange={handleInputChange}
              name="name"
          placeholder="Center Name"/>
  </div>
<br/>
  <div className="input-group">
      <input type="text"
          className="form-control"
          id="contactNo"
              required
             value={diagnostic.contactNo}
                onChange={handleInputChange}
              name="contactNo"
          placeholder="Contact number"/>
  </div>
  <br/>
  <div className="input-group">
      <input type="text"
          className="form-control"
          id="address"
              required
            value={diagnostic.address}
                 onChange={handleInputChange}
              name="address"
          placeholder="Address"/>
  </div>
  <br/>
  <div className="input-group">
      <input type="text"
          className="form-control"
          id="contactEmail"
              required
             value={diagnostic.contactEmail}
                 onChange={handleInputChange}
              name="contactEmail"
          placeholder="Contact Email"/>
  </div>
  
  <br/>
  <div className="col-2 mt-2 ">
      <button id="submit" className="btn btn-primary
          btn-block" onClick={saveDiag}>Submit</button>
  </div>
  </div>
</div>
</form>
</div>
</div>
</div>
</div>
<br/>
<div className="container">
    {/* <div className="row">
      <div className="col">
        <button id="btnDelete" className="btn btn-danger btn-block">Delete</button></div>
      <div className="col">
        <button id="btnUpdate" className="btn btn-success btn-block">Update</button></div>
    </div> */}
    
    <div className="col">
    <Link id="btnDT" className="nav-link active"  to={"/diagcentest"} role="button">Create Diagnostic Test</Link>
    </div>
    </div>
    
    <div className="card" className="carddc1">
            <div className="card-body">
                <div className="d-flex justify-content-center">
                </div>
              <ul>
                {
                  diagnostic1 &&(
                    diagnostic1.map((diag)=>(
                      
                <li key={diag.id}>{diag.id}&nbsp;&nbsp;&nbsp;&nbsp;
                {diag.name}
                <br/>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <Link to={"/diagcen/upd"}>
                            <button  className="btn1 btn-success">
                                Update
                            </button>
                        </Link>&nbsp;&nbsp;&nbsp;&nbsp;
                        {/* <Link to={"/diagcen/upd"}>
                            <button  className="btn1 btn-success">
                                Delete
                            </button>
                        </Link> */}
               </li>
               
                   ) ))
}

              </ul>      
             </div>
             </div>
        </div>
    )
}

export default DiagnosticCenter;