import healthbackgroundimg from "./images/backimg.jpg";
const AboutUs=()=>{
        return(
        <div  style={{
            backgroundImage: `url(${healthbackgroundimg})`,
            height: '100vh',
            backgroundSize:'cover',
            backgroundPosition:'center',
            backgroundRepeat:'no-repeat'
        
          }}>
              <div className="row mt-5">
                  
                  <div className="col-md-6 mb-5 mt-md-0 mt-5 white-text text-center text-md-left">
                    <h1 className="frontcontent">Please Sign-up </h1>
                    <h4 className="fcontent">Maintain Social Distancing! </h4>
                    <h5 className="fcontent">“Health is yet to be transformed by technology.”</h5>
                    <h6 className="quoteauthor"><i> - Pragati Khurana</i></h6><br/><br/>
                    <a className="btn btn-outline-dark wow fadeInCenter" data-wow-delay="0.3s">Learn more</a>
                  </div>
      </div>
     
<div className="jumbotron">
    <div className="container-fluid col-xs-12 col-sm-8">
    </div>
    <div className="col-sm-10">
       <h2 className="card1"><b>Minute Medica</b></h2>
       <p className="cardc1">Simplify the difficult!</p>
       <button type="button" className="b1">Contact Us</button>
        </div>
    </div>
    </div>
    )
}

export default AboutUs;