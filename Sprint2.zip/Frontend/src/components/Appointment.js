import { useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import background from "./images/dr.jpg";
import { ToastContainer, toast } from 'react-toastify';
import {Button} from "reactstrap";

const Appointment=()=>{
    const initialAppointment={
        id:null,
        approvalStatus:""
    };
    const [appointment,setAppointment]=useState(initialAppointment);
    const [diagnosticId,setDiagnosticId]=useState(null);
    const [patientName,setPatientName] =useState("");

    const saveAppointment=()=>{
        appointment.approvalStatus="yes";
        var data={
            approvalStatus:appointment.approvalStatus,
        };
        axios
        .post(`http://localhost:8080/api/appointments/${diagnosticId}/${patientName}`,data)
        .then((response)=>{
            setAppointment({
                id:response.data.id,
                approvalStatus:response.data.approvalStatus,
            });
        })
            .catch(e=>{
                console.log(e);
            });
       
    }


    const handleInputChange1=(e)=>{
        setPatientName(e.target.value);
        console.log(e.target.value);
      };
    const handleInputChange2=(e)=>{
        setDiagnosticId(e.target.value);
        console.log(e.target.value);
      };

    return(
      <div style={{
        backgroundImage: `url(${background})`,
        height: '150vh',
        backgroundSize:'cover'
    
      }}>
         <ToastContainer/>
      <div className="h1">
      <h1>Make Appointment Today!</h1>
      </div>
      <p style={{textAlign:'center',color:'lightblue'}}><b>We are for you</b></p>
      
      <form style={{paddingTop:40,textAlign:'center'}}>
        <div className = "formgroup1">
          <label><b>Patient Name</b></label>
          <input 
          id="patientName"
          required
         //value={appointment.id}
           onChange={handleInputChange1}
          name="patientName"
          placeholder="patient name"/>
          <br/>
          <br/>
          <label><b>Diagnostic Center Id</b></label>
          <input 
          id="diagnosticId"
          required
        //value={user.password}
           onChange={handleInputChange2}
          name="diagnosticId"
          placeholder="diagnostic center id"/>
          <br/>
          <br/>
        

        </div>
      </form>
      <br />
      <br/>
      <div className="button">
        <Link to="/patientdiag">
      <Button color="warning"outline onClick={saveAppointment} >Book Appointment</Button>
      </Link>
      </div>
    <div className="container">
    
   </div>

   </div>
    
    )
}

export default Appointment;