import { useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import background from "./images/doctor2.jpg";
import {Button} from "reactstrap";
import { ToastContainer, toast } from 'react-toastify';


const DiagnosticTest=()=>{
    const btnhandle =()=>{
        toast.success("Test booked successfully",{position: 'top-center'});
    
      };
      const btnhandle1 =()=>{
        toast.success("Test updated successfully",{position: 'top-center'});
    
      };
    const initialTest={
        id:null,
        testName:"",
        testPrice:null,
        normalValue:"",
        units:""
    };

    
    const [test,setTest]=useState(initialTest);
    const [centerId,setCenterId]=useState(null);
    const handleInputChange=event=>{
        const {name,value}=event.target;
        setTest({...test,[name]:value});
    };

    const handleInputChange1=e=>{
       setCenterId(e.target.value);
    };

    const saveTest=()=>{
        var data={
            testName:test.testName,
            testPrice:test.testPrice,
            normalValue:test.normalValue,
            units:test.units,
        };

        axios
        .post(`http://localhost:8080/api/diagnosticTest/${centerId}`,data)
        .then(response=>{
            setTest({
                id:response.data.id,
                testName:response.data.testName,
                testPrice:response.data.testPrice,
                normalValue:response.data.normalValue,
                units:response.data.units
            });
        })
        .catch(e=>{
            console.log(e);
        });
    }
    
    return(
        <div  style={{
            backgroundImage:`url(${background})`,
            height: '100vh',
            backgroundSize:'cover',
            
        }
           }>
               
          
          <ToastContainer/>
          <div className="heading">
          <h1 ><b>Diagnostic Test</b></h1>
          </div>
          
          <form style={{paddingTop:40,textAlign:'center'}}>
            <div className = "formgroup">
              <label><b>DiagnosticCenter Id</b></label>
              <input
              id="centerId"
              required
            //value={test.testName}
               onChange={handleInputChange1}
              name="centerId"
              placeholder="DiagnosticCenter Id "/>
              <br/>
              <br/>
              <label ><b>Test Name</b></label>
              <input 
              id="testName"
              required
            value={test.testName}
               onChange={handleInputChange}
              name="testName"
              placeholder="test name"/>
              <br/>
              <br/>
              <label ><b>Test Price</b></label>
              <input 
              id="testPrice"
              required
             value={test.testPrice}
                onChange={handleInputChange}
              name="testPrice"
              placeholder="test price"/>
              <br/>
              <br/>
              <label ><b>Normal Value</b></label>
              <input 
              id="normalValue"
              required
            value={test.normalValue}
                 onChange={handleInputChange}
              name="normalValue"
              placeholder="normal value"/>
              <br/>
              <br/>
              <label ><b>Units</b></label>
              <input 
              id="units"
              required
             value={test.units}
                 onChange={handleInputChange}
              name="units"
              placeholder="units"/>
    
            
    
            </div>
          </form>
          <br />
          <br/>
          <div className="btn">
              <Link to ="/admin">
          <Button id="btn1" color="warning"outline onClick={btnhandle} onClick={saveTest} >Save Test</Button>
          </Link>
          <Button color="warning"outline onClick={btnhandle1} >Update Test</Button>
          
          </div>
    
        </div>
    )
}

export default DiagnosticTest;