import axios from "axios";
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import testresultbackgroundimg from "./images/testresultbackimg.jpg";

const PersonDiagnostic=()=>{
    const[diagnostic,setDiagnostic]=useState([]);
    useEffect(()=>{

        axios
        .get(`http://localhost:8080/api/diagnosticCenter/list`)
        .then((response)=>{
            setDiagnostic(response.data);
            console.log(response.data);
        })
        .catch((error)=>{
            console.log(error)
        });
        
      },[]);
    return(
        <div style={{
            background: `url(${testresultbackgroundimg})`,
            height: '100vh',
            backgroundSize: 'cover'
          }}>

            <div className="card" className="carddc1">
            <div className="card-body">
                <div className="d-flex justify-content-center">
                </div>
              <ul>
                {
                  diagnostic &&(
                    diagnostic.map((diag)=>(
                      
                <li key={diag.id}>{diag.id}&nbsp;&nbsp;&nbsp;&nbsp;
                {diag.name}
                <br/>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <Link to={"/appointment"}>
                            <button  className="btn1 btn-success">
                                Book Appointment
                            </button>
                        </Link>&nbsp;&nbsp;&nbsp;&nbsp;
                        {/* <Link to={"/diagcen/upd"}>
                            <button  className="btn1 btn-success">
                                Delete
                            </button>
                        </Link> */}
               </li>
               
                   ) ))
}

              </ul>      
             </div>
             </div>
        </div>
    )
}

export default PersonDiagnostic;