import { useState,useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import dchealth from "./images/dcimg.jpg";


const ViewAppointmentAdmin=()=>{

    const [appointment,setAppointment]=useState([]);
    useEffect(()=>{
        axios
      .get(`http://localhost:8080/api/appointments/list`)
      .then((response)=>{
          setAppointment(response.data);
          console.log(response.data);
      })
      .catch((error)=>{
          console.log(error)
      });
      
    });
    return(
        <div style={{
            backgroundImage: `url(${dchealth})`,
            height: '130vh',
            backgroundSize: 'cover'
          }} >
        

      <h2 className="userdcheading">View Appointments</h2>
  <div className="card" className="carddc">
      <div className="card-body">
          <div className="d-flex justify-content-center">
          </div>
        <ul>
            
          <div>
              {
                  appointment &&(
                      appointment.map((app)=>(
          <li key={app.id}>{app.id}&nbsp;&nbsp;&nbsp;&nbsp;
          {app.appointmentDate}
          <br/>
          &nbsp;&nbsp;&nbsp;&nbsp;
          <Link to={"/TestResult"}>
                            <button  className="btn1 btn-success">
                                Create Test Result
                            </button>
                        </Link>&nbsp;&nbsp;&nbsp;&nbsp;
         </li>
    )))
}
        </div>

        </ul>      
       </div>
       </div>
    
  </div>
    )
}

export default ViewAppointmentAdmin;