import { useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import dchealth from "./images/dcimg.jpg";

const UpdateDiagnostic=()=>{
    const initialDiagnostic={
        id:null,
        name:"",
        contactNo:"",
        address:"",
        contactEmail:""
    };

    
    const [diagnostic,setDiagnostic]=useState(initialDiagnostic);
    

    


    const handleInputChange=event=>{
        const {name,value}=event.target;
        setDiagnostic({...diagnostic,[name]:value});
    };

    const saveDiag=()=>{
        var data={
            name:diagnostic.name,
        contactNo:diagnostic.contactNo,
        address:diagnostic.address,
        contactEmail:diagnostic.contactEmail,
        };

        axios
        .patch(`http://localhost:8080/api/diagnosticCenter/updateByName/${diagnostic.name}`,data)
        .then(response=>{
            setDiagnostic({
                //id:response.data.id,
                name:response.data.name,
                contactNo:response.data.contactNo,
                address:response.data.address,
                contactEmail:response.data.contactEmail
            });
        })
        .catch(e=>{
            console.log(e);
        });
    }
    
    return(
        <div
        className="frontbackgroundimg" style={{
          backgroundImage: `url(${dchealth})`,
          height: '130vh',
          backgroundSize: 'cover'
        }}>
            
            <div className="container">
<div className="row">
<div className="col-md-4">
</div>
<div className="col-md-4">
  
<h2 className="dcheading">Diagnostic Center Details</h2>

<div className="form1">
<form>
<div className="card">
  <div className="card-body">
      <div className="d-flex justify-content-center">
      </div>
  <div className="input-group">
      <input type="text"
          className="form-control"
          id="name"
              required
            value={diagnostic.name}
               onChange={handleInputChange}
              name="name"
          placeholder="Center Name"/>
  </div>
<br/>
  <div className="input-group">
      <input type="text"
          className="form-control"
          id="contactNo"
              required
             value={diagnostic.contactNo}
                onChange={handleInputChange}
              name="contactNo"
          placeholder="Contact number"/>
  </div>
  <br/>
  <div className="input-group">
      <input type="text"
          className="form-control"
          id="address"
              required
            value={diagnostic.address}
                 onChange={handleInputChange}
              name="address"
          placeholder="Address"/>
  </div>
  <br/>
  <div className="input-group">
      <input type="text"
          className="form-control"
          id="contactEmail"
              required
             value={diagnostic.contactEmail}
                 onChange={handleInputChange}
              name="contactEmail"
          placeholder="Contact Email"/>
  </div>
  
  <br/>
  <div className="col-2 mt-2 ">
    <Link to="/diagcen">
      <button id="submit" className="btn btn-primary
          btn-block" onClick={saveDiag}>Submit</button>
          </Link>
  </div>
  </div>
</div>
</form>
</div>
</div>
</div>
</div>
                      
        </div>
    )
}
export default UpdateDiagnostic;