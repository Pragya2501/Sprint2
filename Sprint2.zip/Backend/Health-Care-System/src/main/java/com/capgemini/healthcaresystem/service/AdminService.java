package com.capgemini.healthcaresystem.service;

public interface AdminService {

}
